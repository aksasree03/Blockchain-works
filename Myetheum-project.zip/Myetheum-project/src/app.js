// Initialize Web3
const web3 = new Web3("http://127.0.0.1:7545"); // Ganache URL

// Replace with your deployed contract address
const contractAddress = "YOUR_CONTRACT_ADDRESS";

// ABI for the Voting contract
const contractABI = [
    {
        "inputs": [
            { "internalType": "string", "name": "name", "type": "string" }
        ],
        "name": "addCandidate",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            { "internalType": "uint256", "name": "candidateIndex", "type": "uint256" }
        ],
        "name": "vote",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getCandidates",
        "outputs": [
            {
                "components": [
                    { "internalType": "string", "name": "name", "type": "string" },
                    { "internalType": "uint256", "name": "voteCount", "type": "uint256" }
                ],
                "internalType": "struct Voting.Candidate[]",
                "name": "",
                "type": "tuple[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

const votingContract = new web3.eth.Contract(contractABI, contractAddress);

// Fetch and display candidates
async function displayCandidates() {
    const candidates = await votingContract.methods.getCandidates().call();
    const candidatesList = document.getElementById("candidateList");
    candidatesList.innerHTML = "";

    candidates.forEach((candidate, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${index}: ${candidate.name} - ${candidate.voteCount} votes`;
        candidatesList.appendChild(listItem);
    });
}

// Add a new candidate
async function addCandidate() {
    const name = document.getElementById("candidateName").value;
    const accounts = await web3.eth.getAccounts();

    try {
        await votingContract.methods.addCandidate(name).send({ from: accounts[0] });
        alert("Candidate added successfully!");
        displayCandidates();
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Vote for a candidate
async function voteForCandidate() {
    const candidateIndex = document.getElementById("candidateIndex").value;
    const accounts = await web3.eth.getAccounts();

    try {
        await votingContract.methods.vote(candidateIndex).send({ from: accounts[0] });
        alert("Vote submitted successfully!");
        displayCandidates();
    } catch (error) {
        alert("Error: " + error.message);
    }
}

// Load candidates on page load
window.onload = displayCandidates;
